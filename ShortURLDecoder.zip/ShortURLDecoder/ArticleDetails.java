package com.csg.gm.cct.csclientportal.core.entity;

import java.util.Date;

public class ArticleDetails {

       /**
       * Construct and initialize an <code>ArticleDetails</code> object
       * 
        * @param docId
       *            the document id
       * @param userId
       *            the user id (or "client" id) - identifies the customer who is
       *            granted access to the research article
       */
       public ArticleDetails(long docId, long userId,String docFormat) {
              super();
              clientID = userId;
              documentID = docId;
              documentFormat = docFormat;
       }

       /**
       * Get the document id
       * 
        * @return the document id
       */
       public long getDocumentId() {
              return documentID;
       }

       /**
       * Get the client id
       * 
        * @return the client id
       */
       public long getClientId() {
              return clientID;
       }

       public Date getDocumentDate() {
              return documentDate;
       }
       
       public String getdocumentFormat() {
              
              return documentFormat;
       }

       public void setDocumentDate(Date documentDate) {
              this.documentDate = documentDate;
       }

       public Integer getNumExpiryDays() {
              return numExpiryDays;
       }

       public void setNumExpiryDays(Integer numExpiryDays) {
              this.numExpiryDays = numExpiryDays;
       }
       
       

       // Instance variables
       private long documentID;
       private long clientID;
       private Date documentDate;
       private Integer numExpiryDays;
       private String documentFormat;

}
