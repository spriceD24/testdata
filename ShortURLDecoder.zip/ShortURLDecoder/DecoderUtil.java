package com.csg.gm.cct.csclientportal.core.utils;

import com.csg.gm.cct.csclientportal.core.entity.ArticleDetails;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Cookie;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import static com.csg.gm.cct.csclientportal.core.utils.GlobalConstants.FORWARD_SLASH;
import static com.csg.gm.cct.csclientportal.core.utils.GlobalConstants.CSR_DOCUMENT_ID;
import static com.csg.gm.cct.csclientportal.core.utils.GlobalConstants.CSR_USER_ID;
import static com.csg.gm.cct.csclientportal.core.utils.GlobalConstants.REDIRECT_URL;
import static com.csg.gm.cct.csclientportal.core.utils.GlobalConstants.KEY_STRING;
import static com.csg.gm.cct.csclientportal.core.utils.GlobalConstants.EXPIRED_DAYS;
import static com.csg.gm.cct.csclientportal.core.utils.GlobalConstants.ARTICLE_URL;
import static com.csg.gm.cct.csclientportal.core.utils.GlobalConstants.STRING_SEPERATOR;
import static com.csg.gm.cct.csclientportal.core.utils.GlobalConstants.ENCRYPT_USERID;
import static com.csg.gm.cct.csclientportal.core.utils.GlobalConstants.SECURE_PROTOCOL;
/**
 * Util class for URL Decoder Logic
 */

public class DecoderUtil {

	DecoderUtil() {
	}

	private static final Logger LOG = LoggerFactory.getLogger(DecoderUtil.class);

	public static ArticleDetails getArticleDetails(final String shortURL) throws InvalidURLException {
		ShortURLDecoder decoder = new ShortURLDecoder();
		String contextPath = FORWARD_SLASH + KEY_STRING + FORWARD_SLASH;
		ArticleDetails details = decoder.getArticleParametersFromContentURI(contextPath, shortURL);
		if (null != details && 0 != details.getDocumentId()) {
			LOG.info("Inside DecoderUtil before return");
			return details;
		} else {
			throw new InvalidURLException("Decoding of short URL " + shortURL + " failed");
		}

	}

	/**
	 * Method to set the CSRUserId and CSRDocumentId cookies
	 * 
	 * @param UserId
	 *            and DocumentId
	 */
	public static void setCookies(String userId, String documentId, HttpServletResponse response) {
		Cookie userIdCookie = new Cookie(CSR_USER_ID, userId);
		userIdCookie.setPath(FORWARD_SLASH);
		response.addCookie(userIdCookie);
		Cookie documentIdCookie = new Cookie(CSR_DOCUMENT_ID, documentId);
		documentIdCookie.setPath(FORWARD_SLASH);
		response.addCookie(documentIdCookie);
	}

	/**
	 * Method to set the Redirecturl cookie for shorturl redirect from exiry
	 * page
	 * 
	 * @param redirecturl
	 *            - encodedstring from URL
	 */
	public static void setCookies(String redirctUrl,StringBuffer articleUrl, HttpServletResponse response,Boolean isauthuser) {
		String[] urlSegment = redirctUrl.split(FORWARD_SLASH);
		LOG.info("redirctUrl set cookie{}", urlSegment[2]);
		String Encryptuserid= urlSegment[2].substring((urlSegment[2].indexOf(STRING_SEPERATOR))+1);
		Cookie redirctUrlCookie = new Cookie(REDIRECT_URL, urlSegment[2]); // NOSONAR
		redirctUrlCookie.setPath(FORWARD_SLASH); // NOSONAR
		response.addCookie(redirctUrlCookie); // NOSONAR
		articleUrl.replace(0,4,SECURE_PROTOCOL);
		Cookie articleUrlCookie = new Cookie(ARTICLE_URL, articleUrl.toString()); //NOSONAR
        articleUrlCookie.setPath(FORWARD_SLASH); // NOSONAR
        response.addCookie(articleUrlCookie); // NOSONAR
       if (!isauthuser) {
        	Cookie EncryptUseridCookie = new Cookie(ENCRYPT_USERID, Encryptuserid); //NOSONAR
        EncryptUseridCookie.setPath(FORWARD_SLASH); // NOSONAR
        response.addCookie(EncryptUseridCookie); // NOSONAR
        }
	}

	/**
	 * Method to set the Expiry dayscookie to display days passed after expiry.
	 * 
	 * @param Expdays
	 *            - Number of days after expiry
	 */
	public static void setCookies(int expdays, HttpServletResponse response) {
		Cookie expiredDaysCookie = new Cookie(EXPIRED_DAYS, Integer.toString(expdays)); // NOSONAR
		expiredDaysCookie.setPath(FORWARD_SLASH); // NOSONAR
		response.addCookie(expiredDaysCookie); // NOSONAR
	}

}