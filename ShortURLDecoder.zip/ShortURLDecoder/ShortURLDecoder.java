package com.csg.gm.cct.csclientportal.core.utils;

import org.slf4j.LoggerFactory;
import com.csg.gm.cct.csclientportal.core.entity.ArticleDetails;
import java.util.Date;
import org.slf4j.Logger;
import static com.csg.gm.cct.csclientportal.core.utils.GlobalConstants.FORWARD_SLASH;
import static com.csg.gm.cct.csclientportal.core.utils.GlobalConstants.STRING_SEPERATOR;
import static com.csg.gm.cct.csclientportal.core.utils.GlobalConstants.STRING_LIMIT;
import static com.csg.gm.cct.csclientportal.core.utils.GlobalConstants.USER_STRING_LIMIT;
import static com.csg.gm.cct.csclientportal.core.utils.GlobalConstants.CHAR_SPLIT;

public class ShortURLDecoder {

                ShortURLDecoder() {
                }

                /**
                *
                * Class to decrypt the shorturl into DocumentId, UserId
                *
                */
                private static String decrypt(String encryptedString) {
                                LOGGER.debug("Inside decrypt");
                                String returnCharacterString = "";
                                StringBuilder returnStringbld = new StringBuilder();
                                int shiftCharacter = ALPHABET.length() / CHAR_SPLIT;
                                for (char c : encryptedString.toCharArray()) {
                                                int nextIndex = ALPHABET.indexOf(c) - shiftCharacter;
                                                if (nextIndex < 0) {
                                                                nextIndex = ALPHABET.length() + nextIndex;
                                                }
                                                returnStringbld.append(ALPHABET.charAt(nextIndex));
                                                shiftCharacter = ALPHABET.indexOf(c);
                                }
                                returnCharacterString = returnStringbld.toString();
                                return returnCharacterString;
                }

                /**
                * method for splitting the encoded strings UserId and DocumentId
                *
                * @param DecodedString
                *            from the URL
                */
                public static long fromBase62(String input) {
                                LOGGER.debug("Inside frombase62");
                                String baseChars = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz";
                                int srcBase = baseChars.length();
                                long id = 0;
                                StringBuilder sb = new StringBuilder(input);
                                String strCharacter = new String(sb.reverse().toString().toCharArray());
                                for (int i = 0; i < strCharacter.length(); i++) {
                                                int charIndex = baseChars.indexOf(strCharacter.charAt(i));
                                                id += charIndex * (long) Math.pow(srcBase, i);
                                }
                                return id;
                }

                /**
                * method for decoding the documentdate and num of expiry days same method
                * will call getArticleParametersFromURI to decode userId and documentId
                *
                * @param Contextpath
                *            string and shorturl
                */
                public ArticleDetails getArticleParametersFromContentURI(String context, String strShortURI) {
                                strShortURI = strShortURI.replace(context, "");
                                if (strShortURI.indexOf(FORWARD_SLASH) != -1) {
                                                String[] encodedstrGroup = strShortURI.split(FORWARD_SLASH);
                                                String docClientInfo = encodedstrGroup[0];
                                                String webtagInfo = encodedstrGroup[1];
                                                String dateInfo = encodedstrGroup[2];
                                                LOGGER.info(docClientInfo + " Webtag " + webtagInfo + " date " + dateInfo);
                                                ArticleDetails articleDetails = getArticleParametersFromURI(docClientInfo, webtagInfo);

                                                String[] dateVals = dateInfo.split(STRING_SEPERATOR);
                                                if (dateVals.length > 0) {
                                                                articleDetails.setDocumentDate(getDate(new Long(decrypt(dateVals[0]))));
                                                }
                                                if (dateVals.length > 1) {
                                                                articleDetails.setNumExpiryDays(new Integer(decrypt(dateVals[1])));
                                                }                                              
                                                return articleDetails;
                                } else {
                                                return new ArticleDetails(0, 0,"");
                                }
                }

                /**
                * method converting ticks to date format
                * 
                 * @param Ticksvalue
                */
                public static Date getDate(long UTCTicks) {

                                return new Date((UTCTicks - TICKS_AT_EPOCH) / TICKS_PER_MILLISECOND);

                }

                /**
                * method for decoding the userId and documentId
                *
                * @param shorturl
                */

                private ArticleDetails getArticleParametersFromURI(String strShortUrl, String webtagStr) {
                                LOGGER.debug("Getting article parameters from URI using {}", strShortUrl);
                                String strUserid = "";
                                String strWebtag = "";
                                long longDocumentId = 0;
                                long longUserId = 0;
                                long longWebtagId = 0;
                                String combinedStr="";
                                String[] strBeforeBaseCharacter = strShortUrl.split(STRING_SEPERATOR);
                                String docFormat="";
                                combinedStr=strBeforeBaseCharacter[0];
                                combinedStr=combinedStr.replace("_","");
                                LOGGER.info(combinedStr + " combinedStr ");
                                String documentFormat="";
                                if (combinedStr.length()==7)
                                {
                                                documentFormat = combinedStr.substring(5,6);
                                }
                                else
                                {
                                                documentFormat = combinedStr.substring(7,8);
                                }
                                                //documentFormat = decrypt(documentFormat);
                                                LOGGER.info(documentFormat + " documentFormat ");
                                                switch(documentFormat) {
            case "A":
               docFormat = "pdf";
                break;
            case "B":
               docFormat = "xml";
                break;
            case "C":
               docFormat ="text";
                break;
            case "D":
               docFormat ="txt";
                break;
            case "E":
               docFormat ="html";
                break;
            case "G":
               docFormat ="doc";
                break;
            case "J":
               docFormat ="docx";
                break;
            case "H":
               docFormat ="xls";
                break;
            case "L":
               docFormat ="xlsx";
                break;
            case "I":
               docFormat ="ppt";
                break;
            case "M":
               docFormat ="pptx";
                break;
            case "T":
               docFormat ="xlsm";
                break;
                                                
                                                
                                                
                                                //long lngdocumentFormat = fromBase62(documentFormat);
                                                
                                                
                                }              
                                                LOGGER.info(documentFormat + " documentFormat " + docFormat);
                
                                                
                                final int length = strBeforeBaseCharacter[1].length();
                                if ((length >= USER_STRING_LIMIT) && (webtagStr.length() >= STRING_LIMIT)) {
                                                strUserid = decrypt(strBeforeBaseCharacter[1]);
                                                strWebtag = decrypt(webtagStr);
                                                longWebtagId = fromBase62(strWebtag);
                                                longUserId = fromBase62(strUserid);

                                } else { // We go here if the request URI is too short
                                                longUserId = 0;
                                                longWebtagId = 0;
                                }

                                return new ArticleDetails(longWebtagId, longUserId,docFormat);
                }

                // Class variables

                private static final String ALPHABET = "abcdefghijklmnopqrstuvwxyz1234567890ABCDEFGHIJKLMNOPQRSTUVWXYZ";
                private static final Logger LOGGER = LoggerFactory.getLogger(ShortURLDecoder.class.getName());

                // Instance variables

                private static final long TICKS_AT_EPOCH = 621355968000000000L;
                private static final long TICKS_PER_MILLISECOND = 10000;
                /*
                * *
PDF -> A
XML -> B
TEXT-> C
TXT -> D
HTML -> E
HTM -> F
DOC -> G
XLS -> H
PPT -> I
DOCX -> J
DOTX -> K
XLSX -> L
PPTX -> M
XLTX -> N
POTX -> O
PPSX -> P
SLDX -> Q
XLAM -> R
XLSB -> S
XLSM -> T
MHT -> U
ZIP -> V
RAVE -> W
HTML5 -> X
VIDEO -> Z

                */
                

}
